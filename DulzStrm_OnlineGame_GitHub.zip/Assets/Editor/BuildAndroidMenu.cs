#if UNITY_EDITOR
using UnityEditor;
using DulzStrm.Build;

public static class BuildAndroidMenu
{
    [MenuItem("Dulz STRM/Build Android APK")]
    public static void BuildAndroidApk()
    {
        BuildAndroid.Build();
    }
}
#endif
