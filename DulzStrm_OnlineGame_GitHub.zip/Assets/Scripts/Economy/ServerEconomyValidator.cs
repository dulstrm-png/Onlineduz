using UnityEngine;

namespace DulzStrm.Economy
{
    // Foundation only: production currency changes must be performed by the authoritative backend.
    public class ServerEconomyValidator : MonoBehaviour
    {
        public bool ValidateCoinReward(long amount)
        {
            return amount > 0 && amount <= 1_000_000;
        }

        public bool ValidateDiamondReward(long amount)
        {
            return amount > 0 && amount <= 10_000;
        }
    }
}
