using UnityEngine;
using UnityEngine.UI;

namespace DulzStrm.Loading
{
    public class ConnectionStatus : MonoBehaviour
    {
        [SerializeField] private Text statusText;

        public void SetStatus(string status)
        {
            if (statusText != null)
                statusText.text = status;
        }
    }
}
