using UnityEngine;
using UnityEngine.UI;

namespace DulzStrm.Lobby
{
    public class LobbyPlayerCounter : MonoBehaviour
    {
        [SerializeField] private Text counterText;
        [SerializeField] private int maxPlayers = 45;

        public void SetPlayerCount(int currentPlayers)
        {
            currentPlayers = Mathf.Clamp(currentPlayers, 0, maxPlayers);
            if (counterText != null)
                counterText.text = $"{currentPlayers}/{maxPlayers}";
        }
    }
}
