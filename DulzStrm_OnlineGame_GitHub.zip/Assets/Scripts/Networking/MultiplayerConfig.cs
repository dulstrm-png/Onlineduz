using UnityEngine;

namespace DulzStrm.Networking
{
    [CreateAssetMenu(menuName = "Dulz STRM/Multiplayer Config")]
    public class MultiplayerConfig : ScriptableObject
    {
        [Min(1)] public int maxPlayersPerServer = 45;
        [Min(1)] public int recommendedServerTickRate = 30;
        public bool serverAuthoritative = true;
        public bool automaticReconnect = true;
    }
}
