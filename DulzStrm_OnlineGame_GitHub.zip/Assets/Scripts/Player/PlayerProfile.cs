using System;
using UnityEngine;

namespace DulzStrm.Player
{
    [Serializable]
    public class PlayerProfile
    {
        public string playerId;
        public string username;
        public int level = 1;
        public long xp;
        public long coin;
        public long diamond;
    }

    public class PlayerProfileComponent : MonoBehaviour
    {
        public PlayerProfile Profile { get; private set; }

        public void Initialize(string playerId, string username)
        {
            Profile = new PlayerProfile
            {
                playerId = playerId,
                username = username
            };
        }
    }
}
