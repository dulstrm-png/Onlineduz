# Dulz | STRM — Original 3D Online Multiplayer

Prototype project scaffold for an original open-world multiplayer game targeting Android and PC.

## Multiplayer target
- Minimum target: 45 players in one server/room.
- Server-authoritative gameplay architecture.
- `MaxPlayers = 45` is defined in the multiplayer configuration.

## Build APK with GitHub Actions

1. Upload this repository to GitHub.
2. Open **Actions**.
3. Select **Build Android APK**.
4. Click **Run workflow**.
5. Wait for the build.
6. Open the completed workflow run.
7. Download the `DulzStrm-Android-APK` artifact.

The workflow uses Unity Builder and requires a valid Unity license/activation configuration in GitHub repository secrets.

## Important
This is a foundation/scaffold, not a finished AAA game. It contains the project structure, multiplayer configuration, server-authoritative economy skeleton, lobby/player-count UI, and Android CI workflow. Full 3D map assets, animations, vehicles, voice service, dedicated server infrastructure, and production backend still need to be integrated.
