# Roadmap

1. Authentication + player database
2. Lobby + profile
3. Authoritative multiplayer movement
4. Party + friends
5. Voice/proximity chat
6. Modular open-world map
7. Vehicle system
8. Jobs
9. PC/laptop assembly
10. Inventory + selling
11. Shop + economy
12. Missions + XP + achievements
13. House + garage
14. Anti-cheat + admin
15. Optimization + release

Target: 45 concurrent players per server instance.
