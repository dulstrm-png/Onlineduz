# Dedicated Server Notes

The production server should be authoritative and horizontally scalable.

Recommended first deployment:
- 45 player cap per game server.
- 30 Hz authoritative simulation tick.
- Region-aware matchmaking.
- Redis for ephemeral room/session state.
- PostgreSQL for persistent player/economy data.
- Dedicated voice service/provider for realtime voice.
- Server-side validation for movement, inventory, rewards and transactions.

Do not put database credentials or economy secrets in the Unity client.
